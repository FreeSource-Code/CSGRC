# Cybersecurity Governance, Risk, and Compliance in the Age of AI and Global Regulation
### Official Call for Book Chapters (CFP) Website
**Publisher:** Bentham Science (Scopus Indexed)  
**Submission Email:** `cgrc2027@gmail.com`  
**Theme:** "Shaping a Safer Digital Tomorrow"

---

## 🌐 Website Architecture & Pages Overview

This is a production-grade academic book call-for-chapters website designed with the dark navy, cyan neon, and Bentham/Scopus aesthetics matching the official promotional poster.

The portal functions as both an **all-in-one comprehensive landing experience** (`index.html`) and a **multi-page portal** with dedicated deep-dive pages:

| Page | File | Purpose |
| :--- | :--- | :--- |
| **Home Portal** | `index.html` | Master full-experience landing page with all 8 core sections, live countdown clock, interactive topic finder, editors, guidelines, and submission assistant. |
| **About Book** | `about.html` | Complete background narrative from poster, scholarly objectives, Bentham Science publisher profile, and Scopus indexing assurance. |
| **14 Chapter Topics** | `topics.html` | Interactive catalog of all 14 chapters with live keyword search, category filter pills (AI, Regulation, Architecture, Strategic GRC), and 1-click submit triggers. |
| **Editorial Board** | `editors.html` | Profiles of all 5 academic chairs (Dr. Danish Ather, Dr. Atul Malhotra, Dr. Ankur Saxena, Dr. Shambhu Bhardwaj, Dr. Nidhi Sharma) with universities, designations, and contact emails. |
| **Important Dates** | `dates.html` | Live ticking countdown timers (Days, Hours, Minutes, Seconds) for all 4 submission phases leading up to December 2026. |
| **Author Guidelines** | `guidelines.html` | 7,000–8,000 word count rules, IEEE referencing manual & examples, 300+ DPI figure specs, strict No-AI policy, and <10% plagiarism threshold. |
| **Submission Portal** | `submit.html` | 4-step workflow, interactive abstract draft generator, instant mailto compiler to `cgrc2027@gmail.com`, and 1-click downloadable abstract template. |

---

## 🎨 Design System & Technologies

- **HTML5 & Vanilla CSS3**: No heavy external dependencies, 100% responsive on mobile, tablet, and widescreen desktop.
- **Modern Typography**: Outfit (Headings), Inter (Body), Fira Code (Dates, Code, & Tags) via Google Fonts.
- **Cybersecurity Glassmorphism**: Radial gradient backgrounds, glowing neon borders (`#00f0ff`, `#0072ce`, `#ff7a00`), and smooth hover micro-animations.
- **Dynamic JavaScript**:
  - Real-time countdown clocks updating every second.
  - Live search and category filtering for the 14 chapter topics.
  - One-click copy email to clipboard with animated toast notification.
  - Form mailto generator that pre-fills the author's email client with a structured submission template.
  - Client-side downloadable abstract template file generator (`.txt`).
  - Mobile hamburger navigation drawer.
  - Scrollspy navigation indicator & sticky glass header.

---

## 🚀 How to Run / Open Locally

1. Open this project folder in File Explorer:
   `c:\Users\HP\OneDrive\Desktop\Book Chapter Website`
2. Double-click **`index.html`** to open directly in any browser (Google Chrome, Microsoft Edge, Brave, Firefox, Safari).
3. No web server, node, or database setup required. It runs completely offline or online.

---

## 📦 Download Package

A zip archive named `cybersecurity_governance_book_website.zip` is available in this directory containing all files, assets, styles, and scripts ready to be hosted on GitHub Pages, Netlify, Vercel, or institutional servers.
